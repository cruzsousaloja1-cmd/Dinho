import React, { useState, useEffect } from 'react';
import { 
  Driver, 
  LocationPoint, 
  PushNotification, 
  Ride, 
  VehicleCategory 
} from './types';
import { 
  INITIAL_DRIVERS, 
  INITIAL_NOTIFICATIONS, 
  INITIAL_RIDES_HISTORY,
  DEFAULT_NEW_DRIVER
} from './data/mockData';
import { Header } from './components/Header';
import { BottomNav, TabType } from './components/BottomNav';
import { MapRealtime } from './components/MapRealtime';
import { PassengerRideView } from './components/PassengerRideView';
import { DeliveryFlashView } from './components/DeliveryFlashView';
import { DriverPartnerPortal } from './components/DriverPartnerPortal';
import { DriverWorkSelectionView } from './components/DriverWorkSelectionView';
import { AdminDashboard } from './components/AdminDashboard';
import { RideHistoryView } from './components/RideHistoryView';
import { Support24hModal } from './components/Support24hModal';
import { SosModal } from './components/SosModal';
import { PushNotificationToast } from './components/PushNotificationToast';
import { ShareModal } from './components/ShareModal';
import { AuthModal } from './components/AuthModal';
import { DriverLoginScreen } from './components/DriverLoginScreen';
import { SplashScreen } from './components/SplashScreen';
import { FullMapView } from './components/FullMapView';
import { PassengerOptionsView } from './components/PassengerOptionsView';
import { PassengerAccountView } from './components/PassengerAccountView';
import { RatingModal } from './components/RatingModal';
import { saveDriverReview, clearReviewsCache } from './services/reviewService';
import { AppUser } from './types';
import { AlertTriangle, CheckCircle2, X, QrCode } from 'lucide-react';
import confetti from 'canvas-confetti';
import { WEEKLY_FEE, WEEKLY_FEE_TEXT, COMMISSION, WEEKLY_FEE_BADGE } from './config/pricing';
import { 
  saveSessionUser,
  getSessionUser,
  mapSupabaseRowToAppUser,
  saveIsolatedRide, 
  saveUserAccount, 
  normalizeEmail,
  ADMIN_EMAIL,
  deleteUserAccount,
  deleteAllUserAccounts,
  activateAllDriverAccounts
} from './services/userService';
import {
  cancelVoiceSpeech,
  notifyRideFinished
} from './services/audioNotificationService';
import {
  getDriverBalance,
  addDriverEarnings,
  clearWalletMemoryCache
} from './services/walletService';
import {
  getCorridasSupabase,
  getCorridaByIdSupabase,
  acceptCorridaSupabase,
  updateCorridaStatusSupabase,
  saveCorridaSupabase,
  savePagamentoSupabase,
  getUsuarioSupabase,
  getAllDriversFromSupabase,
  getOnlineDriversFromSupabase,
  updateDriverOnlineStatusSupabase,
  getAllPassengersFromSupabase,
  subscribeToCorridasRealtime,
  purgeLegacyTestLocalStorage,
  normalizeRideCategory,
  getPassengerDebtSupabase,
  clearPassengerDebtSupabase,
  hydrateRidesWithUserPhotosSupabase,
  fetchUsuarioPhotoByIdentity
} from './supabase';
import { generateUniqueRideConfirmationCode } from './services/pricingService';

export default function App() {
  const initialSessionRef = React.useRef<AppUser | null | undefined>(undefined);
  if (initialSessionRef.current === undefined) {
    initialSessionRef.current = getSessionUser();
  }
  const initialUser = initialSessionRef.current;

  const resolveInitialTab = (u: AppUser | null): TabType => {
    if (!u) return 'driver_portal';
    const isAdminUser =
      u.role === 'admin' ||
      u.isAdmin ||
      String(u.tipo || '').toUpperCase() === 'ADM' ||
      (u.email || '').toLowerCase() === ADMIN_EMAIL;
    if (isAdminUser) return 'admin';
    const tLower = String(u.tipo || '').toLowerCase().trim();
    const isDriverUser =
      u.role === 'driver' ||
      u.role === 'motoboy' ||
      tLower === 'driver' ||
      tLower === 'motorista' ||
      tLower === 'motoboy' ||
      tLower === 'motorista_economico' ||
      tLower === 'motorista_confort' ||
      tLower === 'motoboy_passageiro' ||
      tLower === 'motoboy_entregas';
    return isDriverUser ? 'driver_portal' : 'rides';
  };

  // Global States
  const [activeTab, setActiveTab] = useState<TabType>(() => resolveInitialTab(initialUser));
  const [isFullMapOpen, setIsFullMapOpen] = useState(false);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [currentDriver, setCurrentDriver] = useState<Driver>(
    () => initialUser?.driverData || DEFAULT_NEW_DRIVER
  );
  const [ridesHistory, setRidesHistory] = useState<Ride[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [activeRide, setActiveRide] = useState<Ride | null>(null);
  const [completedRideForRating, setCompletedRideForRating] = useState<Ride | null>(null);
  const [isRatingModalOpen, setIsRatingModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<VehicleCategory>('economica');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<'pix' | 'credit_card' | 'dinheiro'>('pix');
  const [optionsLaunchNonce, setOptionsLaunchNonce] = useState(0);

  // Registered Passengers State (100% Supabase)
  const [passengers, setPassengers] = useState<AppUser[]>([]);

  // 1. Authentication & Session (salvo em race_usuario_logado + sincronizado no Supabase)
  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => initialUser);
  const [passengerDebt, setPassengerDebt] = useState<{
    debtAmount: number;
    isBlocked: boolean;
    unpaidRideIds: string[];
  }>({ debtAmount: 0, isBlocked: false, unpaidRideIds: [] });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [loginSuccessBanner, setLoginSuccessBanner] = useState<string | null>(null);
  const [showStartupSplash, setShowStartupSplash] = useState(true);
  const [showPostAuthSplash, setShowPostAuthSplash] = useState(false);

  // Map and Route States
  const [pickup, setPickup] = useState<LocationPoint | null>(null);
  const [destination, setDestination] = useState<LocationPoint | null>(null);
  const [hasSearchedRoute, setHasSearchedRoute] = useState(false);
  const [mapSelectionMode, setMapSelectionMode] = useState<'pickup' | 'destination' | null>(null);

  // Driver live position during active ride
  const [driverPosition, setDriverPosition] = useState<{ lat: number; lng: number } | undefined>(undefined);

  // Modals & Push Notifications
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isSosOpen, setIsSosOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isNotifCenterOpen, setIsNotifCenterOpen] = useState(false);
  const [notifications, setNotifications] = useState<PushNotification[]>(INITIAL_NOTIFICATIONS);
  const [currentToast, setCurrentToast] = useState<PushNotification | null>(null);

  // 2. Startup: limpar resquícios antigos de localStorage e validar sessão ativa diretamente no Supabase
  useEffect(() => {
    purgeLegacyTestLocalStorage(true);

    let active = true;
    const initFromSupabase = async () => {
      try {
        const [cloudDrivers, onlineRpcDrivers, cloudPassengers] = await Promise.all([
          getAllDriversFromSupabase(),
          getOnlineDriversFromSupabase(),
          getAllPassengersFromSupabase(),
        ]);
        const mergedDriversMap = new Map<string, Driver>();
        [...cloudDrivers, ...onlineRpcDrivers].forEach((drv) => {
          const key = drv.id || drv.email || `${drv.name}-${drv.vehiclePlate}`;
          if (!key) return;
          const prev = mergedDriversMap.get(key);
          if (!prev) {
            mergedDriversMap.set(key, drv);
          } else {
            mergedDriversMap.set(key, {
              ...prev,
              ...drv,
              avatar: drv.avatar || prev.avatar,
              status: prev.status === 'online' || drv.status === 'online' ? 'online' : drv.status,
            });
          }
        });
        const mergedDrivers = Array.from(mergedDriversMap.values());
        if (active) {
          setDrivers(mergedDrivers);
          setPassengers(cloudPassengers);
        }
      } catch {}

      const session = getSessionUser();
      const sessionIdentifier = session?.email || session?.login || '';
      if (!session || !sessionIdentifier) return;

      try {
        const cloudRow = await getUsuarioSupabase(sessionIdentifier);
        if (!active) return;

        if (cloudRow && cloudRow.status === 'bloqueado') {
          // Conta explicitamente bloqueada pela administração
          saveSessionUser(null);
          setCurrentUser(null);
          setCurrentDriver(DEFAULT_NEW_DRIVER);
          return;
        }

        if (!cloudRow) {
          // Mantém o race_usuario_logado salvo no dispositivo até clicar em Sair
          return;
        }

        const { user: hydratedUser, driver: hydratedDriver } = mapSupabaseRowToAppUser(cloudRow);
        const mergedUser: AppUser = {
          ...hydratedUser,
          avatar: hydratedUser.avatar || session.avatar || '',
        };
        setCurrentUser(mergedUser);
        saveSessionUser(mergedUser);

        if (
          hydratedUser.role === 'admin' ||
          hydratedUser.isAdmin ||
          String(hydratedUser.tipo || '').toUpperCase() === 'ADM' ||
          hydratedUser.email.toLowerCase() === ADMIN_EMAIL
        ) {
          setActiveTab('admin');
          return;
        }

        const hydratedTipoLower = String(hydratedUser.tipo || '').toLowerCase().trim();
        const isDriverOrMotoboy =
          hydratedUser.role === 'driver' ||
          hydratedUser.role === 'motoboy' ||
          hydratedTipoLower === 'driver' ||
          hydratedTipoLower === 'motorista' ||
          hydratedTipoLower === 'motoboy' ||
          hydratedTipoLower === 'motorista_economico' ||
          hydratedTipoLower === 'motorista_confort' ||
          hydratedTipoLower === 'motoboy_passageiro' ||
          hydratedTipoLower === 'motoboy_entregas';

        if (isDriverOrMotoboy && hydratedDriver) {
          const isConfigured =
            hydratedDriver.categoryConfigured !== false &&
            Boolean(hydratedDriver.vehiclePlate?.trim() && hydratedDriver.vehicleModel?.trim()) &&
            hydratedDriver.requirementsConfirmed === true;
          const currentBalance = getDriverBalance(hydratedDriver.id, hydratedDriver.walletBalance || 0);
          const updatedMatched: Driver = {
            ...hydratedDriver,
            categoryConfigured:
              hydratedDriver.categoryConfigured !== false &&
              Boolean(hydratedDriver.vehiclePlate?.trim() && hydratedDriver.vehicleModel?.trim()),
            requirementsConfirmed: hydratedDriver.requirementsConfirmed === true,
            walletBalance: currentBalance,
            weeklyPlanActive: true,
            status: isConfigured && hydratedDriver.status === 'online' ? 'online' : 'offline',
          };
          setCurrentDriver(updatedMatched);
          setActiveTab('driver_portal');
          if (isConfigured && updatedMatched.status === 'online') {
            captureAndSyncDriverGps(updatedMatched, 'online');
          }
        } else {
          setActiveTab('rides');
        }
      } catch {
        // Se offline momentaneamente, mantém sessão mínima sem dados mockados
      }
    };

    initFromSupabase();
    return () => {
      active = false;
    };
  }, []);

  // Helper para capturar GPS real do condutor e gravar status ONLINE/OFFLINE no Supabase
  const captureAndSyncDriverGps = (driverTarget: Driver, status: 'online' | 'offline') => {
    if (!driverTarget?.email && !driverTarget?.id) return;
    if (status === 'offline') {
      updateDriverOnlineStatusSupabase({
        id: driverTarget.id,
        email: driverTarget.email,
        status: 'offline',
      }).catch(() => {});
      return;
    }

    updateDriverOnlineStatusSupabase({
      id: driverTarget.id,
      email: driverTarget.email,
      status: 'online',
      lat: driverTarget.lat,
      lng: driverTarget.lng,
    }).catch(() => {});

    if (typeof navigator !== 'undefined' && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setCurrentDriver((prev) =>
            prev && (prev.id === driverTarget.id || prev.email === driverTarget.email)
              ? { ...prev, status: 'online', lat, lng }
              : prev
          );
          setDrivers((prev) =>
            prev.map((d) =>
              d.id === driverTarget.id || d.email === driverTarget.email
                ? { ...d, status: 'online', lat, lng }
                : d
            )
          );
          updateDriverOnlineStatusSupabase({
            id: driverTarget.id,
            email: driverTarget.email,
            status: 'online',
            lat,
            lng,
          }).catch(() => {});
        },
        () => {},
        { enableHighAccuracy: true, timeout: 8000 }
      );
    }
  };

  const refreshRidesHistory = async (userTarget: AppUser | null = currentUser) => {
    if (!userTarget) {
      setRidesHistory([]);
      return;
    }
    setIsLoadingHistory(true);
    try {
      const cloudRides = await getCorridasSupabase(userTarget);
      setRidesHistory(cloudRides || []);
    } catch (err) {
      console.warn('Aviso ao sincronizar corridas do Supabase:', err);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  // Sincronizar corridas isoladas da nuvem Supabase para o usuário logado
  useEffect(() => {
    if (!currentUser) {
      setRidesHistory([]);
      setPassengerDebt({ debtAmount: 0, isBlocked: false, unpaidRideIds: [] });
      return;
    }
    refreshRidesHistory(currentUser);

    getPassengerDebtSupabase(currentUser)
      .then((debt) => {
        setPassengerDebt(debt);
      })
      .catch(() => {});
  }, [currentUser, activeTab]);

  const handleClearPassengerDebt = async (
    asaasPaymentId: string,
    asaasStatus: 'RECEIVED' | 'CONFIRMED'
  ) => {
    if (!currentUser) return;
    const ok = await clearPassengerDebtSupabase({
      user: currentUser,
      debtAmount: passengerDebt.debtAmount,
      asaasPaymentId,
      asaasStatus,
      unpaidRideIds: passengerDebt.unpaidRideIds,
    });
    if (ok) {
      const updatedUser: AppUser = {
        ...currentUser,
        debtAmount: 0,
        isBlockedDebt: false,
        debtRideId: undefined,
      };
      setCurrentUser(updatedUser);
      saveSessionUser(updatedUser);
      setPassengerDebt({ debtAmount: 0, isBlocked: false, unpaidRideIds: [] });
      triggerPush(
        'Dívida quitada via PIX Asaas!',
        'Seu acesso para novas corridas na RACE foi liberado.',
        'financial'
      );
    }
  };

  // Polling em tempo real dos motoristas/motoboys ONLINE no Supabase (para o mapa do passageiro)
  useEffect(() => {
    if (!currentUser) return;
    let active = true;

    const syncOnlineDrivers = async () => {
      try {
        const onlineList = await getOnlineDriversFromSupabase();
        if (!active) return;

        setDrivers((prev) => {
          const onlineByKey = new Map<string, Driver>();
          onlineList.forEach((d) => {
            const k = (d.email || d.id || '').toLowerCase();
            if (k) onlineByKey.set(k, d);
          });

          const merged: Driver[] = [...onlineList];
          prev.forEach((existing) => {
            const k = (existing.email || existing.id || '').toLowerCase();
            if (k && !onlineByKey.has(k)) {
              merged.push({ ...existing, status: 'offline' });
            }
          });
          return merged;
        });
      } catch {}
    };

    syncOnlineDrivers();
    const timer = setInterval(syncOnlineDrivers, 3500);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, [currentUser, isFullMapOpen, activeTab]);

  // 3. Rota Secreta /admin: abre o AdminDashboard se o usuário for admin, senão volta para tela preta de login
  useEffect(() => {
    const checkSecretAdminRoute = () => {
      const hash = window.location.hash.toLowerCase();
      const path = window.location.pathname.toLowerCase();
      const isTryingAdmin = hash === '#/admin' || hash === '#admin' || path.endsWith('/admin');

      if (isTryingAdmin) {
        const savedUser: AppUser | null = currentUser || getSessionUser();

        const isUserAdmin = Boolean(
          savedUser &&
            (savedUser.role === 'admin' ||
              savedUser.isAdmin ||
              String(savedUser.tipo || '').toUpperCase() === 'ADM' ||
              savedUser.email?.trim().toLowerCase() === ADMIN_EMAIL)
        );

        if (isUserAdmin && savedUser) {
          setCurrentUser(savedUser);
          setActiveTab('admin');
        } else {
          saveSessionUser(null);
          setCurrentUser(null);
          if (window.location.hash) {
            try {
              window.history.replaceState(null, '', window.location.pathname);
            } catch {}
          }
        }
      }
    };

    checkSecretAdminRoute();
    window.addEventListener('hashchange', checkSecretAdminRoute);
    return () => window.removeEventListener('hashchange', checkSecretAdminRoute);
  }, [currentUser]);

  // Motoristas trabalham livres sem bloqueio de taxa semanal (modelo 15% Race / 85% motorista)

  // Realtime Supabase ('corridas') + Polling em tempo real enquanto a corrida do passageiro estiver em MODO PROCURANDO
  useEffect(() => {
    const curSt = String(activeRide?.status || '').toLowerCase();
    const isSearching =
      curSt === 'searching' || curSt === 'procurando' || curSt === 'procurando_motorista';
    if (!activeRide || !isSearching) return;

    let isMounted = true;
    let handledAccept = false;

    const applyLatestRideUpdate = async (latestRide: Ride) => {
      if (!isMounted || !latestRide) return;
      const st = String(latestRide.status || '').toLowerCase();

      if (st === 'cancelled' || st === 'cancelada') {
        cancelVoiceSpeech();
        setActiveRide(null);
        setIsFullMapOpen(false);
        return;
      }

      if (
        !handledAccept &&
        (st === 'accepted' ||
          st === 'aceita' ||
          st === 'em_andamento' ||
          st === 'driver_assigned' ||
          st === 'driver_arriving' ||
          st === 'in_progress')
      ) {
        handledAccept = true;
        const [hydratedLatest] = await hydrateRidesWithUserPhotosSupabase([latestRide]).catch(() => [latestRide]);
        if (!isMounted) return;
        const resolvedRide = hydratedLatest || latestRide;
        let fullDriver = resolvedRide.driver;
        if (fullDriver) {
          let matched = drivers.find(
            (d) =>
              (fullDriver?.id && d.id === fullDriver.id) ||
              (fullDriver?.email && d.email.toLowerCase() === fullDriver.email.toLowerCase())
          );
          if (!matched || !matched.avatar) {
            const refreshedDrivers = await getAllDriversFromSupabase().catch(() => []);
            if (!isMounted) return;
            if (refreshedDrivers.length > 0) setDrivers(refreshedDrivers);
            const foundInRefreshed = refreshedDrivers.find(
              (d) =>
                (fullDriver?.id && d.id === fullDriver.id) ||
                (fullDriver?.email && d.email.toLowerCase() === fullDriver.email.toLowerCase())
            );
            if (foundInRefreshed) matched = foundInRefreshed;
          }
          if (matched) {
            fullDriver = {
              ...matched,
              ...fullDriver,
              avatar: fullDriver.avatar || matched.avatar || '',
              vehicleModel: fullDriver.vehicleModel || matched.vehicleModel || '',
              vehiclePlate: fullDriver.vehiclePlate || matched.vehiclePlate || '',
              vehicleColor: fullDriver.vehicleColor || matched.vehicleColor || '',
              vehicleYear: fullDriver.vehicleYear || matched.vehicleYear || 2023,
              phone: fullDriver.phone || matched.phone || '',
              rating: fullDriver.rating || matched.rating || 0,
            };
          }
          if (!fullDriver.avatar && (fullDriver.email || fullDriver.id)) {
            const drvProfile = await fetchUsuarioPhotoByIdentity({
              id: fullDriver.id,
              email: fullDriver.email,
            }).catch(() => null);
            if (!isMounted) return;
            if (drvProfile?.avatar) {
              fullDriver = {
                ...fullDriver,
                avatar: drvProfile.avatar,
                vehiclePlate: fullDriver.vehiclePlate || drvProfile.vehiclePlate || '',
                vehicleModel: fullDriver.vehicleModel || drvProfile.vehicleModel || '',
                phone: fullDriver.phone || drvProfile.phone || '',
              };
            }
          }
        }
        const acceptedDriverName = (fullDriver?.name || '').trim() || 'Motorista';
        setActiveRide((curr) =>
          curr
            ? {
                ...curr,
                id: resolvedRide.id || curr.id,
                passengerAvatar: resolvedRide.passengerAvatar || curr.passengerAvatar || currentUser?.avatar || '',
                status: 'aceita',
                driver: fullDriver || curr.driver,
              }
            : curr
        );
        triggerPush(
          '🚗 Corrida Aceita!',
          `${acceptedDriverName} aceitou sua corrida`,
          'ride'
        );
      }
    };

    const unsubscribeRealtime = subscribeToCorridasRealtime({
      onUpdate: (updRide) => {
        if (!isMounted) return;
        const matchesId =
          !activeRide.id ||
          !updRide.id ||
          String(updRide.id) === String(activeRide.id);
        const matchesCode =
          Boolean(activeRide.confirmationCode && updRide.confirmationCode) &&
          updRide.confirmationCode === activeRide.confirmationCode;
        if (matchesId || matchesCode) {
          applyLatestRideUpdate(updRide);
        }
      },
    });

    const checkAccepted = async () => {
      try {
        let latestRide: Ride | null = null;
        if (activeRide.id && /^\d+$/.test(String(activeRide.id))) {
          latestRide = await getCorridaByIdSupabase(activeRide.id);
        } else if (currentUser) {
          const allUserRides = await getCorridasSupabase(currentUser);
          latestRide = allUserRides[0] || null;
        }
        if (latestRide) {
          await applyLatestRideUpdate(latestRide);
        }
      } catch {}
    };

    const interval = setInterval(checkAccepted, 2500);
    return () => {
      isMounted = false;
      unsubscribeRealtime();
      clearInterval(interval);
    };
  }, [activeRide?.id, activeRide?.status, activeRide?.confirmationCode, currentUser, drivers]);

  // Hidrata automaticamente fotos do motorista e passageiro direto do Supabase sempre que abrir a chamada/corrida
  useEffect(() => {
    if (!activeRide) return;
    const needsPassengerPhoto = !activeRide.passengerAvatar;
    const needsDriverPhoto = Boolean(
      activeRide.driver && (!activeRide.driver.avatar || !activeRide.driver.vehiclePlate)
    );
    if (!needsPassengerPhoto && !needsDriverPhoto) return;

    let mounted = true;
    hydrateRidesWithUserPhotosSupabase([activeRide])
      .then(([hydrated]) => {
        if (!mounted || !hydrated) return;
        const nextPassengerAvatar = hydrated.passengerAvatar || activeRide.passengerAvatar || currentUser?.avatar || '';
        const nextDriver = hydrated.driver || activeRide.driver;
        if (
          nextPassengerAvatar !== (activeRide.passengerAvatar || '') ||
          nextDriver?.avatar !== activeRide.driver?.avatar ||
          nextDriver?.vehiclePlate !== activeRide.driver?.vehiclePlate
        ) {
          setActiveRide((curr) =>
            curr
              ? {
                  ...curr,
                  passengerAvatar: nextPassengerAvatar || curr.passengerAvatar,
                  driver: nextDriver
                    ? {
                        ...nextDriver,
                        avatar: nextDriver.avatar || curr.driver?.avatar || '',
                      }
                    : curr.driver,
                }
              : curr
          );
        }
      })
      .catch(() => {});

    return () => {
      mounted = false;
    };
  }, [
    activeRide?.id,
    activeRide?.status,
    activeRide?.passengerAvatar,
    activeRide?.driver?.id,
    activeRide?.driver?.email,
    activeRide?.driver?.avatar,
    activeRide?.driver?.vehiclePlate,
    currentUser?.avatar,
  ]);

  // Simulated GPS movement ONLY after ride is accepted by a driver
  useEffect(() => {
    const st = String(activeRide?.status || '').toLowerCase();
    const isRideAccepted =
      st === 'accepted' ||
      st === 'aceita' ||
      st === 'driver_assigned' ||
      st === 'driver_arriving' ||
      st === 'in_progress';

    if (!activeRide || !activeRide.driver || !isRideAccepted) {
      setDriverPosition(undefined);
      return;
    }

    let step = 0;
    const startLat = activeRide.driver.lat;
    const startLng = activeRide.driver.lng;
    const targetLat = activeRide.pickup.lat;
    const targetLng = activeRide.pickup.lng;

    const interval = setInterval(() => {
      step += 1;
      const progress = Math.min(step / 30, 1);
      const curLat = startLat + (targetLat - startLat) * progress;
      const curLng = startLng + (targetLng - startLng) * progress;

      setDriverPosition({ lat: curLat, lng: curLng });

      if (progress >= 1) {
        clearInterval(interval);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [activeRide]);

  // Dispatch a push notification
  const triggerPush = (title: string, message: string, type: 'ride' | 'financial' | 'safety' | 'system' = 'ride') => {
    const newNotif: PushNotification = {
      id: `push-${Date.now()}`,
      title,
      message,
      time: 'Agora',
      type,
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
    setCurrentToast(newNotif);

    // Auto dismiss toast after 6 seconds
    setTimeout(() => {
      setCurrentToast((curr) => (curr?.id === newNotif.id ? null : curr));
    }, 6000);
  };

  // Passenger confirma corrida -> só cria se for Dinheiro ou Asaas RECEIVED/CONFIRMED (e sem dívida bloqueada)
  const handleStartRide = (ride: Ride) => {
    if (passengerDebt.isBlocked && passengerDebt.debtAmount > 0) {
      triggerPush(
        'Conta bloqueada por dívida em aberto',
        `Quite o valor de R$ ${passengerDebt.debtAmount.toFixed(2).replace('.', ',')} via PIX Asaas antes de solicitar nova corrida.`,
        'financial'
      );
      return;
    }
    const isCash = ride.paymentMethod === 'money' || ride.paymentMethod === 'dinheiro';
    const isAsaasConfirmed =
      ride.asaasStatus === 'RECEIVED' || ride.asaasStatus === 'CONFIRMED';

    if (!isCash && (!isAsaasConfirmed || ride.paymentStatus !== 'paid')) {
      triggerPush(
        'Pague primeiro para chamar o motorista',
        'Aguarde a confirmação real do pagamento no Asaas (PIX ou Cartão) ou escolha Dinheiro.',
        'ride'
      );
      return;
    }

    const confirmationCode = ride.confirmationCode || generateUniqueRideConfirmationCode();
    const resolvedPassengerAvatar = ride.passengerAvatar || currentUser?.avatar || '';
    const startedRide: Ride = {
      ...ride,
      passengerId: ride.passengerId || currentUser?.id,
      passengerEmail: ride.passengerEmail || currentUser?.email,
      passengerAvatar: resolvedPassengerAvatar,
      paymentMethod: isCash ? 'dinheiro' : ride.paymentMethod,
      paymentStatus: isCash ? 'pending' : 'paid',
      status: 'procurando',
      confirmationCode,
    };
    setActiveRide(startedRide);
    if (!resolvedPassengerAvatar && (currentUser?.email || currentUser?.id)) {
      fetchUsuarioPhotoByIdentity({ id: currentUser?.id, email: currentUser?.email })
        .then((prof) => {
          if (prof?.avatar) {
            setActiveRide((curr) =>
              curr && curr.confirmationCode === confirmationCode
                ? { ...curr, passengerAvatar: prof.avatar }
                : curr
            );
          }
        })
        .catch(() => {});
    }
    setRidesHistory((prev) => [
      startedRide,
      ...prev.filter((r) => (startedRide.id ? r.id !== startedRide.id : r !== startedRide)),
    ]);
    saveCorridaSupabase(startedRide, currentUser)
      .then((res) => {
        if (res.success && res.id) {
          const syncedId = res.id;
          setActiveRide((curr) =>
            curr && (curr === startedRide || (startedRide.id && curr.id === startedRide.id))
              ? { ...curr, id: syncedId }
              : curr
          );
          setRidesHistory((prev) =>
            prev.map((r) =>
              r === startedRide || (startedRide.id && r.id === startedRide.id) ? { ...r, id: syncedId } : r
            )
          );
        }
      })
      .catch(() => {});

    // Dinheiro NÃO passa pelo Asaas — só grava pagamento Asaas quando for PIX / Cartão
    if (!isCash) {
      savePagamentoSupabase({
        id_motorista: startedRide.driver?.id || '',
        nome_motorista: startedRide.driver?.name || '',
        email_motorista: startedRide.driver?.email || '',
        valor: startedRide.price,
        tipo: 'corrida',
        status: 'pago',
        chave_pix: '',
      }).catch(() => {});
    }
    setIsFullMapOpen(true);

    // Notificação silenciosa para o radar (sem voz enquanto aguarda motorista aceitar)
    const driverAlert: PushNotification = {
      id: `driver-call-${Date.now()}`,
      title: isCash
        ? `💵 Pagamento em DINHEIRO - Receba ${`R$ ${ride.price.toFixed(2).replace('.', ',')}`} do passageiro`
        : '🔔 Nova corrida - Aceitar',
      message: `${ride.passengerName || 'Passageiro'} • ${ride.pickup.address} → ${ride.destination.address} (R$ ${ride.price.toFixed(2).replace('.', ',')})`,
      time: 'Agora',
      type: 'ride',
      read: false,
    };
    setNotifications((prev) => [driverAlert, ...prev]);

    triggerPush(
      '🔍 Procurando motorista...',
      isCash
        ? 'Corrida em dinheiro criada no sistema! Buscando motoristas online no mapa.'
        : 'Buscando motoristas online próximos a você no mapa.',
      'ride'
    );
  };

  // Complete active ride - fecha mapa e abre modal de Avaliação
  const handleCompleteRide = () => {
    if (!activeRide) return;
    const isCash = activeRide.paymentMethod === 'money' || activeRide.paymentMethod === 'dinheiro';
    const finalStatus = isCash ? 'finalizada' : 'completed';
    const updatedRide: Ride = {
      ...activeRide,
      paymentMethod: isCash ? 'dinheiro' : activeRide.paymentMethod,
      status: finalStatus,
      completedAt: new Date().toISOString(),
    };
    setActiveRide(updatedRide);
    setCompletedRideForRating(updatedRide);
    setIsRatingModalOpen(true);
    setIsFullMapOpen(false); // Retorna do mapa para tela de avaliação
    notifyRideFinished();

    if (activeRide.id && /^\d+$/.test(String(activeRide.id))) {
      updateCorridaStatusSupabase(activeRide.id, finalStatus, isCash ? 'dinheiro' : undefined).catch(() => {});
    }

    // Credita o valor da corrida na carteira do motorista
    if (activeRide.driver?.id) {
      const updatedBalance = addDriverEarnings(activeRide.driver.id, activeRide.price);
      setCurrentDriver((prev) => {
        if (!prev) return prev;
        if (prev.id === activeRide.driver?.id) {
          return {
            ...prev,
            walletBalance: updatedBalance,
            earningsToday: (prev.earningsToday || 0) + activeRide.price,
            earningsWeek: (prev.earningsWeek || 0) + activeRide.price,
          };
        }
        return prev;
      });
      setDrivers((prev) =>
        prev.map((d) =>
          d.id === activeRide.driver?.id
            ? {
                ...d,
                walletBalance: updatedBalance,
                earningsToday: d.earningsToday + activeRide.price,
                earningsWeek: d.earningsWeek + activeRide.price,
              }
            : d
        )
      );
    }

    triggerPush(
      '🏁 Viagem Finalizada!',
      isCash
        ? `Corrida em dinheiro (R$ ${activeRide.price.toFixed(2).replace('.', ',')}) finalizada! Avalie seu condutor.`
        : `Total de R$ ${activeRide.price.toFixed(2)} creditado no saldo do motorista! Avalie seu condutor.`,
      'ride'
    );
  };

  // Submit rating
  const handleSubmitRating = (rating: number, comment: string, issueComment?: string) => {
    const targetRide = completedRideForRating || activeRide;
    if (!targetRide) return;

    const finalizedRide: Ride = {
      ...targetRide,
      passengerId: currentUser?.id,
      passengerEmail: currentUser?.email,
      passengerName: currentUser?.name || targetRide.passengerName || 'Passageiro',
      ratingGivenToDriver: rating,
      ratingComment: comment,
      issueComment: issueComment,
    };
    setRidesHistory((prev) => [
      finalizedRide,
      ...prev.filter((r) => (finalizedRide.id ? r.id !== finalizedRide.id : r !== targetRide)),
    ]);
    saveIsolatedRide(finalizedRide, currentUser);

    // Salva avaliação real na memória da sessão e no Supabase
    saveDriverReview({
      rideId: finalizedRide.id,
      driverId: targetRide.driver?.id || '',
      driverName: targetRide.driver?.name || '',
      driverVehicle: targetRide.driver?.vehicleModel
        ? `${targetRide.driver.vehicleModel} - ${targetRide.driver.vehiclePlate}`
        : '',
      passengerName: currentUser?.name || targetRide.passengerName || 'Passageiro',
      passengerEmail: currentUser?.email,
      rating,
      comment,
      issueComment,
    });

    // Atualiza a média de avaliação do condutor
    if (targetRide.driver?.id) {
      const driverId = targetRide.driver.id;
      setDrivers((prev) =>
        prev.map((d) => {
          if (d.id === driverId) {
            const currentTotal = d.totalRides || 0;
            const newAverage = Number(((d.rating * currentTotal + rating) / (currentTotal + 1)).toFixed(2));
            return {
              ...d,
              rating: newAverage,
              totalRides: currentTotal + 1,
            };
          }
          return d;
        })
      );

      setCurrentDriver((prev) => {
        if (!prev) return prev;
        const currentTotal = prev.totalRides || 0;
        const newAverage = Number(((prev.rating * currentTotal + rating) / (currentTotal + 1)).toFixed(2));
        return {
          ...prev,
          rating: newAverage,
          totalRides: currentTotal + 1,
        };
      });
    }

    setActiveRide(null);
    setCompletedRideForRating(null);
    setIsRatingModalOpen(false);

    triggerPush(
      '⭐ Obrigado pela Avaliação!',
      `Sua nota de ${rating} estrelas foi registrada com sucesso!`,
      'safety'
    );
  };

  // Cancel active ride (para tudo, sem voz e cancela no Supabase)
  const handleCancelRide = () => {
    cancelVoiceSpeech();
    if (activeRide?.id) {
      updateCorridaStatusSupabase(activeRide.id, 'cancelled').catch(() => {});
    }
    setActiveRide(null);
    setIsFullMapOpen(false);
    setDriverPosition(undefined);
    triggerPush(
      '❌ Busca Cancelada',
      'A corrida foi cancelada. Nenhum valor adicional foi cobrado.',
      'system'
    );
  };

  // Delivery Flash order -> direciona para pagamento obrigatório antes de chamar motoboy
  const handleStartDelivery = (ride: Ride) => {
    const isCash = ride.paymentMethod === 'money' || ride.paymentMethod === 'dinheiro';
    const isAsaasConfirmed =
      ride.asaasStatus === 'RECEIVED' || ride.asaasStatus === 'CONFIRMED';
    if (!isCash && (!isAsaasConfirmed || ride.paymentStatus !== 'paid')) {
      setPickup(ride.pickup);
      setDestination(ride.destination);
      setSelectedCategory('moto_entrega');
      setActiveTab('rides');
      triggerPush(
        'Pague primeiro para chamar o motorista',
        'Conclua o pagamento no Asaas (PIX/Cartão) ou escolha Dinheiro na aba CORRIDA antes de chamar o motoboy.',
        'ride'
      );
      return;
    }
    handleStartRide(ride);
  };

  // Map interaction
  const handleMapClick = (coords: { lat: number; lng: number; address: string }) => {
    if (mapSelectionMode === 'pickup') {
      setPickup(coords);
      setMapSelectionMode(null);
      triggerPush('📍 Ponto de Embarque Marcado', coords.address, 'system');
    } else if (mapSelectionMode === 'destination') {
      setDestination(coords);
      setMapSelectionMode(null);
      triggerPush('🏁 Destino Marcado', coords.address, 'system');
    }
  };

  // Driver register / updates (100% Supabase)
  const handleRegisterDriver = (newDriver: Driver) => {
    const isConfigured =
      newDriver.categoryConfigured !== false &&
      Boolean(newDriver.vehiclePlate?.trim() && newDriver.vehicleModel?.trim());
    const normalizedDriver: Driver = {
      ...newDriver,
      categoryConfigured: isConfigured,
      status: isConfigured ? newDriver.status : 'offline',
    };
    setDrivers((prev) => [normalizedDriver, ...prev.filter((d) => d.id !== normalizedDriver.id)]);
    setCurrentDriver(normalizedDriver);

    const isMoto =
      normalizedDriver.category === 'moto_passageiro' ||
      normalizedDriver.category === 'moto_entrega';
    const userTipo = !isConfigured
      ? isMoto
        ? 'motoboy'
        : 'driver'
      : normalizedDriver.category === 'economica'
      ? 'motorista_economico'
      : normalizedDriver.category === 'confort'
      ? 'motorista_confort'
      : normalizedDriver.category === 'moto_passageiro'
      ? 'motoboy_passageiro'
      : 'motoboy_entregas';

    // Sincroniza a conta isolada no Supabase
    saveUserAccount({
      id: normalizedDriver.id,
      name: normalizedDriver.name,
      email: normalizedDriver.email,
      phone: normalizedDriver.phone,
      password: normalizedDriver.password,
      role: isMoto ? 'motoboy' : 'driver',
      tipo: userTipo,
      placa: normalizedDriver.vehiclePlate,
      avatar: normalizedDriver.avatar,
      rating: normalizedDriver.rating,
      driverData: normalizedDriver,
      createdAt: new Date().toISOString(),
    });

    triggerPush(
      isConfigured ? '🎉 Bem-vindo à RACE!' : 'Escolha sua categoria no app',
      isConfigured
        ? `Cadastro de ${normalizedDriver.name} concluído com sucesso! Você fica com 85% de cada corrida, Race fica com 15% - sem mensalidade.`
        : `Olá ${normalizedDriver.name}! Escolha sua categoria e informe os dados do veículo para liberar o botão verde ONLINE.`,
      isConfigured ? 'financial' : 'system'
    );
  };

  const handleUpdateDriver = (updated: Driver) => {
    const isConfigured =
      updated.categoryConfigured !== false &&
      Boolean(updated.vehiclePlate?.trim() && updated.vehicleModel?.trim());
    const safeUpdated: Driver = {
      ...updated,
      categoryConfigured: isConfigured,
      status: isConfigured ? updated.status : 'offline',
    };
    setCurrentDriver(safeUpdated);
    setDrivers((prev) => [safeUpdated, ...prev.filter((d) => d.id !== safeUpdated.id)]);

    if (safeUpdated.email) {
      const isMoto =
        safeUpdated.category === 'moto_passageiro' ||
        safeUpdated.category === 'moto_entrega';
      const userTipo = !isConfigured
        ? isMoto
          ? 'motoboy'
          : 'driver'
        : safeUpdated.category === 'economica'
        ? 'motorista_economico'
        : safeUpdated.category === 'confort'
        ? 'motorista_confort'
        : safeUpdated.category === 'moto_passageiro'
        ? 'motoboy_passageiro'
        : 'motoboy_entregas';

      saveUserAccount({
        id: safeUpdated.id,
        name: safeUpdated.name,
        email: safeUpdated.email,
        phone: safeUpdated.phone,
        password: safeUpdated.password,
        role: isMoto ? 'motoboy' : 'driver',
        tipo: userTipo,
        placa: safeUpdated.vehiclePlate,
        avatar: safeUpdated.avatar,
        rating: safeUpdated.rating,
        driverData: safeUpdated,
        createdAt: safeUpdated.registrationDate || new Date().toISOString(),
      }, false);
    }
  };

  const handleToggleDriverStatus = (driverId: string) => {
    setDrivers((prev) =>
      prev.map((d) => {
        if (d.id !== driverId) return d;
        const nextStatus: 'online' | 'offline' = d.status === 'online' ? 'offline' : 'online';
        updateDriverOnlineStatusSupabase({
          id: d.id,
          email: d.email,
          status: nextStatus,
          lat: d.lat,
          lng: d.lng,
        }).catch(() => {});
        return { ...d, status: nextStatus };
      })
    );
  };

  const handleRenewWeeklyPlan = (driverTarget?: Driver | null) => {
    const target = driverTarget || currentDriver;
    if (!target) return;
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    const updated: Driver = {
      ...target,
      weeklyFeePaidAt: now.toISOString(),
      weeklyFeeExpiresAt: expiresAt.toISOString(),
      weeklyPlanExpiresAt: expiresAt.toISOString(),
      weeklyPlanActive: true,
      weeklyPlanPrice: WEEKLY_FEE,
      status: 'online',
    };
    handleUpdateDriver(updated);
    if (currentUser?.driverData?.id === updated.id) {
      setCurrentUser((prev) => (prev ? { ...prev, driverData: updated } : null));
    }
    triggerPush(
      '🎉 Status Online Ativado!',
      'Modelo sem taxas fixas: você fica com 85% de cada corrida e a Race com 15%. Sem taxa semanal ou mensalidade!',
      'financial'
    );
    try {
      confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
    } catch {}
  };

  const handleApproveDriver = (driverId: string) => {
    setDrivers((prev) =>
      prev.map((d) =>
        d.id === driverId
          ? { ...d, cnhVerified: true, vehicleVerified: true, weeklyPlanActive: true }
          : d
      )
    );
    triggerPush('🛡️ Auditoria Aprovada', 'Documentos de condutor validados com sucesso.', 'safety');
  };

  const handleApproveWeeklyPayment = (driver: Driver) => {
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    const updated: Driver = {
      ...driver,
      weeklyFeePaidAt: now.toISOString(),
      weeklyFeeExpiresAt: expiresAt.toISOString(),
      weeklyPlanExpiresAt: expiresAt.toISOString(),
      weeklyPlanActive: true,
      weeklyPlanPrice: WEEKLY_FEE,
      status: 'online',
      pendingPayment: driver.pendingPayment
        ? {
            ...driver.pendingPayment,
            status: 'approved',
          }
        : null,
    };
    handleUpdateDriver(updated);
    if (currentUser?.driverData?.id === updated.id) {
      setCurrentUser((prev) => (prev ? { ...prev, driverData: updated } : null));
    }

    // Salvar na tabela public.pagamentos no Supabase (id gerado automaticamente)
    savePagamentoSupabase({
      id_motorista: driver.id,
      nome_motorista: driver.name,
      email_motorista: driver.email,
      valor: driver.walletBalance || 0,
      status: 'approved',
      chave_pix: driver.pixKey || '',
    });

    triggerPush(
      'Cadastro Ativo!',
      `${driver.name} está ONLINE! Você fica com 85% de cada corrida, Race fica com 15% - sem mensalidade, sem taxa para trabalhar.`,
      'financial'
    );
    try {
      confetti({ particleCount: 75, spread: 80, origin: { y: 0.6 } });
    } catch {}
  };

  const handleRejectWeeklyPayment = (driver: Driver) => {
    const updated: Driver = {
      ...driver,
      pendingPayment: driver.pendingPayment
        ? {
            ...driver.pendingPayment,
            status: 'rejected',
          }
        : null,
    };
    handleUpdateDriver(updated);
    if (currentUser?.driverData?.id === updated.id) {
      setCurrentUser((prev) => (prev ? { ...prev, driverData: updated } : null));
    }

    // Salvar na tabela public.pagamentos no Supabase (id gerado automaticamente)
    savePagamentoSupabase({
      id_motorista: driver.id,
      nome_motorista: driver.name,
      email_motorista: driver.email,
      valor: 0,
      status: 'rejected',
      chave_pix: driver.pixKey || '',
    });

    triggerPush(
      'Solicitação Atualizada',
      `O registro de ${driver.name} foi atualizado pelo administrador.`,
      'financial'
    );
  };

  // Admin Management: Remover Motorista Individual
  const handleRemoveDriver = (driverId: string, email: string) => {
    deleteUserAccount(email, driverId);
    setDrivers((prev) => prev.filter((d) => d.id !== driverId && normalizeEmail(d.email) !== normalizeEmail(email)));
    triggerPush('🗑️ Cadastro Removido', `O cadastro do motorista ${email} foi excluído com sucesso.`, 'system');
  };

  // Admin Management: Remover Passageiro Individual
  const handleRemovePassenger = (passengerId: string, email: string) => {
    deleteUserAccount(email, passengerId);
    setPassengers((prev) => prev.filter((p) => p.id !== passengerId && normalizeEmail(p.email) !== normalizeEmail(email)));
    triggerPush('🗑️ Passageiro Removido', `O cadastro do passageiro ${email} foi excluído com sucesso.`, 'system');
  };

  // Admin Management: Ativar TODOS os motoristas/motoboys
  const handleActivateAllDrivers = () => {
    const updated = activateAllDriverAccounts(drivers);
    setDrivers(updated);
    triggerPush(
      '✅ Todos os Cadastros Ativados',
      `Todos os ${updated.length} condutores foram ativados com 7 dias liberados e status ONLINE!`,
      'financial'
    );
    try {
      confetti({ particleCount: 80, spread: 90, origin: { y: 0.6 } });
    } catch {}
  };

  // Admin Management: Remover e Zerar TODOS os cadastros e dados de teste
  const handleRemoveAllAccounts = async () => {
    await deleteAllUserAccounts();
    setDrivers([]);
    setPassengers([]);
    setRidesHistory([]);
    setActiveRide(null);
    clearWalletMemoryCache();
    clearReviewsCache();
    triggerPush(
      '🗑️ Dados Zerados no Supabase',
      'Todos os cadastros não-ADM, corridas e pagamentos foram zerados com sucesso.',
      'system'
    );
  };

  // Auth success handler: direciona cada perfil direto para sua tela oficial
  const handleAuthSuccess = (user: AppUser, driver?: Driver) => {
    setCurrentUser(user);
    saveSessionUser(user);
    setHasSearchedRoute(false);
    setShowPostAuthSplash(true);
    if (driver) {
      const isConfigured =
        driver.categoryConfigured !== false &&
        Boolean(driver.vehiclePlate?.trim() && driver.vehicleModel?.trim());
      const nextDrv: Driver = {
        ...driver,
        categoryConfigured: isConfigured,
        status: isConfigured ? 'online' : 'offline',
      };
      setDrivers((prev) => [nextDrv, ...prev.filter((d) => d.id !== nextDrv.id)]);
      setCurrentDriver(nextDrv);
      if (isConfigured) {
        captureAndSyncDriverGps(nextDrv, 'online');
      }
    }
    const isAdminUser = user.role === 'admin' || user.isAdmin || user.email?.toLowerCase() === ADMIN_EMAIL;
    const isDriverUser =
      user.role === 'driver' ||
      user.role === 'motoboy' ||
      Boolean(driver) ||
      Boolean(user.driverData);
    setActiveTab(isAdminUser ? 'admin' : isDriverUser ? 'driver_portal' : 'rides');
    const roleName = user.role === 'driver' ? 'Motorista/Motoboy Parceiro' : 'Passageiro';
    setLoginSuccessBanner(
      `Bem-vindo(a), ${user.name}! Acesso validado com login e senha (${roleName}). Você entrou direto na página de atendimento de corridas RACE!`
    );
    triggerPush(
      '🎉 Acesso Liberado!',
      `Olá ${user.name}! Você entrou direto na Central de Atendimento de Corridas RACE.`,
      'system'
    );
  };

  const handleLogout = () => {
    if (currentDriver?.email) {
      updateDriverOnlineStatusSupabase({
        id: currentDriver.id,
        email: currentDriver.email,
        status: 'offline',
      }).catch(() => {});
    }
    saveSessionUser(null);
    purgeLegacyTestLocalStorage(false);
    clearWalletMemoryCache();
    clearReviewsCache();
    setCurrentUser(null);
    setShowPostAuthSplash(false);
    setHasSearchedRoute(false);
    setPickup(null);
    setDestination(null);
    setCurrentDriver(DEFAULT_NEW_DRIVER);
    setRidesHistory([]);
    setActiveRide(null);
    setActiveTab('rides');
    triggerPush('Sessão Encerrada', 'Você saiu da sua conta RACE.', 'system');
  };

  const unreadNotifsCount = notifications.filter((n) => !n.read).length;

  // Reusable real-time GPS map component instance (SOMENTE motoristas ONLINE com categoria configurada)
  const mapElement = (
    <MapRealtime
      drivers={drivers.filter((d) => d.status === 'online' && d.categoryConfigured !== false)}
      pickup={pickup}
      destination={destination}
      activeDriver={activeRide?.driver || null}
      rideStatus={activeRide?.status || 'idle'}
      driverPosition={driverPosition}
      onMapClick={handleMapClick}
      selectionMode={mapSelectionMode}
    />
  );

  // Tela preta Splash com logo RACE vermelho/laranja grande (90px) por 3 segundos toda vez que entrar no app
  if (showStartupSplash || showPostAuthSplash) {
    return (
      <SplashScreen
        durationMs={3000}
        onComplete={() => {
          setShowStartupSplash(false);
          setShowPostAuthSplash(false);
        }}
      />
    );
  }

  // 1. Quando o app abre deslogado, NÃO mostrar PassengerRideView, Header ou BottomNav.
  // Mostrar tela de login de motorista full-screen com design preto e laranja igual ao print.
  if (!currentUser) {
    return (
      <DriverLoginScreen
        drivers={drivers}
        passengers={passengers}
        onLoginSuccess={(user, driver) => {
          setCurrentUser(user);
          saveSessionUser(user);
          setHasSearchedRoute(false);
          setShowPostAuthSplash(true);

          // Se for Administrador (tipo = ADM ou admin@race.com.br)
          if (
            user.role === 'admin' ||
            user.isAdmin ||
            String(user.tipo || '').toUpperCase() === 'ADM' ||
            user.email?.toLowerCase() === 'admin@race.com.br'
          ) {
            setActiveTab('admin');
            setLoginSuccessBanner(
              'Bem-vindo, Administrador Geral! Painel de controle e auditoria liberados.'
            );
            return;
          }

          const loginTipoLower = String(user.tipo || '').toLowerCase().trim();
          const isDriverOrMotoboy =
            user.role === 'driver' ||
            user.role === 'motoboy' ||
            loginTipoLower === 'driver' ||
            loginTipoLower === 'motorista' ||
            loginTipoLower === 'motoboy' ||
            loginTipoLower === 'motorista_economico' ||
            loginTipoLower === 'motorista_confort' ||
            loginTipoLower === 'motoboy_passageiro' ||
            loginTipoLower === 'motoboy_entregas';

          if (isDriverOrMotoboy) {
            const targetDriver: Driver = driver || user.driverData || {
              ...DEFAULT_NEW_DRIVER,
              id: user.id,
              name: user.name,
              email: user.email,
              phone: user.phone,
              avatar: user.avatar || '',
              category: user.role === 'motoboy' || loginTipoLower.includes('moto') ? 'moto_passageiro' : 'economica',
              categoryConfigured: false,
              status: 'offline',
            };
            const hasVehicleFields =
              targetDriver.categoryConfigured !== false &&
              Boolean(targetDriver.vehiclePlate?.trim() && targetDriver.vehicleModel?.trim());
            const isConfigured = hasVehicleFields && targetDriver.requirementsConfirmed === true;
            const currentBal = getDriverBalance(targetDriver.id, targetDriver.walletBalance || 0);
            const driverWithBal: Driver = {
              ...targetDriver,
              categoryConfigured: hasVehicleFields,
              requirementsConfirmed: targetDriver.requirementsConfirmed === true,
              walletBalance: currentBal,
              weeklyPlanActive: isConfigured,
              status: isConfigured && targetDriver.status === 'online' ? 'online' : 'offline',
            };
            setCurrentDriver(driverWithBal);
            setDrivers((prev) => [driverWithBal, ...prev.filter((d) => d.id !== driverWithBal.id)]);
            if (isConfigured && driverWithBal.status === 'online') {
              captureAndSyncDriverGps(driverWithBal, 'online');
            }
            setActiveTab('driver_portal');
            setLoginSuccessBanner(
              isConfigured
                ? `Bem-vindo(a), ${targetDriver.name}! Central de Corridas pronta para receber chamados. Você fica com 85% de cada corrida sem mensalidade!`
                : hasVehicleFields
                ? `Bem-vindo(a), ${targetDriver.name}! Confirme as exigências da sua modalidade para voltar a ficar ONLINE.`
                : `Bem-vindo(a), ${targetDriver.name}! Escolha sua modalidade e preencha os dados do veículo para liberar o botão verde ONLINE.`
            );
          } else {
            // Passageiro: vai direto para tela de pedir corrida com mapa
            setActiveTab('rides');
            setLoginSuccessBanner(
              `Olá, ${user.name}! Escolha seu ponto de embarque e destino para solicitar sua corrida ou entrega.`
            );
          }
        }}
        onRegisterDriverSuccess={(_user, newDriver) => {
          handleRegisterDriver(newDriver);
        }}
        onRegisterMotoboySuccess={(_user, newMotoboy) => {
          handleRegisterDriver(newMotoboy);
        }}
        onRegisterPassengerSuccess={(newUser) => {
          setPassengers((prev) => [newUser, ...prev.filter((p) => p.id !== newUser.id)]);
        }}
      />
    );
  }

  const userTipoLower = String(currentUser.tipo || '').toLowerCase().trim();
  const isUserDriver = Boolean(
    currentUser && (
      currentUser.role === 'driver' ||
      currentUser.role === 'motoboy' ||
      Boolean(currentUser.driverData) ||
      userTipoLower === 'driver' ||
      userTipoLower === 'motorista' ||
      userTipoLower === 'motoboy' ||
      userTipoLower === 'motorista_economico' ||
      userTipoLower === 'motorista_confort' ||
      userTipoLower === 'motoboy_passageiro' ||
      userTipoLower === 'motoboy_entregas'
    )
  );

  const isDriverCategoryConfigured = Boolean(
    currentDriver.categoryConfigured !== false &&
    currentDriver.vehiclePlate?.trim() &&
    currentDriver.vehicleModel?.trim() &&
    currentDriver.requirementsConfirmed === true
  );

  // TELA FULLSCREEN OBRIGATÓRIA DE ESCOLHA DE MODALIDADE E CONFIRMAÇÃO DE EXIGÊNCIAS
  // Não mostra tela de passageiro, Header ou BottomNav até concluir o preenchimento e confirmação das exigências.
  if (isUserDriver && !isDriverCategoryConfigured) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] text-white px-4 py-6 sm:py-10 overflow-y-auto">
        <DriverWorkSelectionView
          currentUser={currentUser}
          isMandatorySetup={true}
          onLogout={handleLogout}
          onCompleteDriverRegister={(newDriver) => {
            const configuredDriver: Driver = {
              ...newDriver,
              categoryConfigured: true,
              requirementsConfirmed: true,
              status: 'online',
              weeklyPlanActive: true,
            };
            const isMoto =
              configuredDriver.category === 'moto_passageiro' ||
              configuredDriver.category === 'moto_entrega';
            const nextTipo =
              configuredDriver.category === 'economica'
                ? 'motorista_economico'
                : configuredDriver.category === 'confort'
                ? 'motorista_confort'
                : configuredDriver.category === 'moto_passageiro'
                ? 'motoboy_passageiro'
                : 'motoboy_entregas';
            const updatedUser: AppUser = {
              ...currentUser,
              role: isMoto ? 'motoboy' : 'driver',
              tipo: nextTipo,
              placa: configuredDriver.vehiclePlate,
              driverData: configuredDriver,
            };
            setCurrentUser(updatedUser);
            saveSessionUser(updatedUser);
            handleRegisterDriver(configuredDriver);
            captureAndSyncDriverGps(configuredDriver, 'online');
            setActiveTab('driver_portal');
            setLoginSuccessBanner(
              `Modalidade configurada! Você já está ONLINE e pronto para receber corridas na RACE.`
            );
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans pb-28 selection:bg-slate-900 selection:text-white w-full max-w-[100vw] overflow-x-hidden box-border">
      {/* Prominent RACE Brand Header */}
      <Header
        unreadNotifsCount={unreadNotifsCount}
        onOpenNotifications={() => setIsNotifCenterOpen(true)}
        onOpenSupport={() => setIsSupportOpen(true)}
        onOpenSos={() => setIsSosOpen(true)}
        onOpenShare={() => setIsShareOpen(true)}
        activeRole={
          activeTab === 'admin'
            ? 'admin'
            : currentUser?.role === 'admin' ||
              currentUser?.isAdmin ||
              String(currentUser?.tipo || '').toUpperCase() === 'ADM' ||
              currentUser?.email?.toLowerCase() === 'admin@race.com.br'
            ? 'admin'
            : currentUser?.role === 'motoboy' || currentUser?.tipo === 'motoboy'
            ? 'driver'
            : activeTab === 'driver_portal'
            ? 'driver'
            : 'passenger'
        }
        onChangeRole={(role) => {
          if (role === 'passenger') setActiveTab('rides');
          if (role === 'driver') setActiveTab('driver_portal');
          if (role === 'admin') {
            const isUserAdmin = Boolean(
              currentUser?.email?.toLowerCase() === 'admin@race.com.br' ||
              currentUser?.role === 'admin' ||
              currentUser?.isAdmin === true ||
              String(currentUser?.tipo || '').toUpperCase() === 'ADM'
            );
            if (isUserAdmin) {
              setActiveTab('admin');
            }
          }
        }}
        currentUser={currentUser}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onLogout={handleLogout}
      />

      {/* Main Layout Container */}
      <main className="flex-1 max-w-4xl w-full max-w-[100vw] mx-auto px-4 py-4 sm:p-5 overflow-x-hidden box-border">
        {/* 1. Corridas (Passageiro / Condutor) com MAPA ABAIXO DAS OPÇÕES DE CORRIDA */}
        {activeTab === 'rides' && (
          <PassengerRideView
            onStartRide={handleStartRide}
            activeRide={activeRide}
            onCancelRide={handleCancelRide}
            onCompleteRide={handleCompleteRide}
            onSubmitRating={handleSubmitRating}
            pickup={pickup}
            destination={destination}
            setPickup={setPickup}
            setDestination={setDestination}
            onSelectOnMap={(type) => setMapSelectionMode(type)}
            availableDrivers={drivers}
            mapElement={mapElement}
            currentUser={currentUser}
            currentDriver={currentDriver}
            loginSuccessBanner={loginSuccessBanner}
            onClearLoginBanner={() => setLoginSuccessBanner(null)}
            passengerDebt={passengerDebt}
            onClearPassengerDebt={handleClearPassengerDebt}
            selectedCategoryProp={selectedCategory}
            onCategoryChange={setSelectedCategory}
            paymentMethodProp={selectedPaymentMethod}
            onPaymentMethodChange={setSelectedPaymentMethod}
            optionsLaunchNonce={optionsLaunchNonce}
            hasSearchedRoute={hasSearchedRoute}
            onRouteSearched={setHasSearchedRoute}
            onOpenFullMap={() => {
              const isRideAuthorized = Boolean(
                activeRide &&
                (activeRide.paymentStatus === 'paid' ||
                  activeRide.paymentMethod === 'money' ||
                  activeRide.paymentMethod === 'dinheiro')
              );
              if (!isRideAuthorized) {
                triggerPush(
                  'Pague o PIX primeiro, estamos aguardando confirmação do Asaas',
                  'Preencha seu endereço de início e chegada com número, escolha a categoria e aguarde o Asaas confirmar o pagamento (ou escolha Dinheiro) para liberar o mapa.',
                  'ride'
                );
                return;
              }
              setIsFullMapOpen(true);
            }}
          />
        )}

        {/* 2. Entregas Flash (Motoboy para entrega) */}
        {activeTab === 'delivery' && (
          <DeliveryFlashView
            onStartDelivery={handleStartDelivery}
            availableMotoboys={drivers.filter((d) => d.category === 'moto_entrega')}
            pickup={pickup}
            destination={destination}
            setPickup={setPickup}
            setDestination={setDestination}
          />
        )}

        {/* 3. Condutor & Cadastro (85% para você, 15% Race - Sem mensalidade) */}
        {activeTab === 'driver_portal' && (
          isUserDriver ? (
            <DriverPartnerPortal
              currentDriver={currentDriver}
              currentUser={currentUser}
              rides={ridesHistory}
              activeRide={activeRide}
              onAcceptIncomingRide={(ride) => {
                const resolvedDriver: Driver = {
                  ...currentDriver,
                  avatar: currentDriver.avatar || currentUser?.avatar || '',
                };
                const acceptedObj: Ride = { ...ride, driver: resolvedDriver, status: 'accepted' };
                setActiveRide(acceptedObj);
                if (ride.id && /^\d+$/.test(String(ride.id))) {
                  acceptCorridaSupabase(ride.id, resolvedDriver).catch(() => {});
                }
              }}
              onUpdateDriver={handleUpdateDriver}
              onUpdateUserProfile={(updatedUser) => {
                setCurrentUser(updatedUser);
                saveSessionUser(updatedUser);
              }}
              onRegisterDriver={(newDriver) => {
                handleRegisterDriver(newDriver);
              }}
              onLoginDriverSuccess={(user, driver) => {
                setCurrentUser(user);
                setShowPostAuthSplash(true);
                if (driver) {
                  const isConfigured =
                    driver.categoryConfigured !== false &&
                    Boolean(driver.vehiclePlate?.trim() && driver.vehicleModel?.trim());
                  const nextDrv: Driver = {
                    ...driver,
                    categoryConfigured: isConfigured,
                    status: isConfigured ? 'online' : 'offline',
                  };
                  setCurrentDriver(nextDrv);
                  if (isConfigured) {
                    captureAndSyncDriverGps(nextDrv, 'online');
                  }
                }
                saveSessionUser(user);
                setLoginSuccessBanner(
                  `Bem-vindo(a), ${user.name}! Você fica com 85% de cada corrida, Race fica com 15% - sem mensalidade, sem taxa para trabalhar.`
                );
              }}
              onNavigateToRides={() => {
                setActiveTab('rides');
                setLoginSuccessBanner(
                  `Você alternou para a página de pedidos de corrida (Passageiro).`
                );
              }}
              onOpenSupport={() => setIsSupportOpen(true)}
              onOpenShare={() => setIsShareOpen(true)}
              onRenewWeeklyPlan={handleRenewWeeklyPlan}
              onTriggerToast={(title, msg, type) => triggerPush(title, msg, type || 'financial')}
            />
          ) : (
            <DriverWorkSelectionView
              currentUser={currentUser!}
              onCompleteDriverRegister={(newDriver) => {
                handleRegisterDriver(newDriver);
                const isMoto = newDriver.category === 'moto_entrega' || newDriver.category === 'moto_passageiro';
                const updatedUser: AppUser = {
                  ...currentUser!,
                  role: isMoto ? 'motoboy' : 'driver',
                  tipo: newDriver.category === 'economica' ? 'motorista_economico' :
                        newDriver.category === 'confort' ? 'motorista_confort' :
                        newDriver.category === 'moto_passageiro' ? 'motoboy_passageiro' : 'motoboy_entregas',
                  placa: newDriver.vehiclePlate,
                  driverData: newDriver,
                };
                setCurrentUser(updatedUser);
                setCurrentDriver(newDriver);
                saveSessionUser(updatedUser);
                setLoginSuccessBanner(
                  `Parabéns, ${newDriver.name}! Cadastro de motorista homologado com sucesso!`
                );
              }}
              onBackToRides={() => setActiveTab('rides')}
              onRenewWeeklyPlan={handleRenewWeeklyPlan}
            />
          )
        )}

        {/* 4. Histórico Completo & Recibos - APENAS dados do próprio usuário no Supabase */}
        {activeTab === 'history' && (
          <RideHistoryView
            rides={ridesHistory}
            activeRide={activeRide}
            isLoading={isLoadingHistory}
            onRefresh={() => refreshRidesHistory(currentUser)}
          />
        )}

        {/* 5. Opções de Categoria para Passageiro (4 Categorias + Forma de Pagamento) */}
        {activeTab === 'passenger_options' && (
          <PassengerOptionsView
            selectedCategory={selectedCategory}
            onSelectCategory={(cat) => setSelectedCategory(cat)}
            selectedPaymentMethod={selectedPaymentMethod}
            onSelectPaymentMethod={(method) => setSelectedPaymentMethod(method)}
            pickup={pickup}
            destination={destination}
            hasSearchedRoute={hasSearchedRoute}
            availableDrivers={drivers}
            onNavigateToRides={(chosenCategory) => {
              if (chosenCategory) {
                setSelectedCategory(chosenCategory);
              }
              setOptionsLaunchNonce((n) => n + 1);
              setActiveTab('rides');
            }}
          />
        )}

        {/* 6. Conta & Perfil do Passageiro (Nome, E-mail, WhatsApp, Login, Endereço com Meu GPS, Sair) */}
        {activeTab === 'passenger_account' && (
          <PassengerAccountView
            currentUser={currentUser}
            currentAddress={pickup?.address}
            pickup={pickup}
            onUpdateAddress={(addr, lat, lng) => setPickup({ address: addr, lat, lng })}
            onLogout={handleLogout}
            onNavigateToHistory={() => setActiveTab('history')}
            onOpenSupport={() => setIsSupportOpen(true)}
            onOpenShare={() => setIsShareOpen(true)}
            onUpdateAvatar={(avatarBase64) => {
              setCurrentUser((prev) => {
                const next = prev ? { ...prev, avatar: avatarBase64 } : null;
                if (next) saveSessionUser(next);
                return next;
              });
            }}
            onUpdateProfile={(updatedUser) => {
              setCurrentUser(updatedUser);
              saveSessionUser(updatedUser);
            }}
          />
        )}

        {/* 5. Painel Administrativo Master - ADM */}
        {activeTab === 'admin' && (
          (currentUser?.email?.toLowerCase() === ADMIN_EMAIL || currentUser?.role === 'admin' || currentUser?.isAdmin || String(currentUser?.tipo || '').toUpperCase() === 'ADM') ? (
            <AdminDashboard
              drivers={drivers}
              rides={ridesHistory}
              passengers={passengers}
              onApproveDriver={handleApproveDriver}
              onToggleDriverStatus={handleToggleDriverStatus}
              onOpenShare={() => setIsShareOpen(true)}
              onApproveWeeklyPayment={handleApproveWeeklyPayment}
              onRejectWeeklyPayment={handleRejectWeeklyPayment}
              onRemoveDriver={handleRemoveDriver}
              onRemovePassenger={handleRemovePassenger}
              onActivateAllDrivers={handleActivateAllDrivers}
              onRemoveAllAccounts={handleRemoveAllAccounts}
            />
          ) : (
            <div className="text-center py-12 p-6 bg-zinc-950 border-2 border-[#ff6a00] rounded-3xl text-white space-y-3 shadow-xl">
              <AlertTriangle className="w-12 h-12 text-[#ff6a00] mx-auto animate-pulse" />
              <h3 className="text-xl font-heading font-black text-white">Acesso Exclusivo da Administração</h3>
              <p className="text-sm text-zinc-300 max-w-md mx-auto">
                Apenas o login oficial <strong>{ADMIN_EMAIL}</strong> tem permissão para auditar a frota geral, conferir comprovantes PIX e gerenciar todos os motoristas de Indaiatuba.
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('rides')}
                className="mt-4 px-6 py-2.5 bg-[#ff6a00] hover:bg-[#e05e00] text-white font-heading font-black text-sm rounded-xl cursor-pointer"
              >
                Voltar para Corridas
              </button>
            </div>
          )
        )}
      </main>

      {/* Floating Push Notification Toast */}
      <PushNotificationToast
        notification={currentToast}
        onDismiss={() => setCurrentToast(null)}
        isOpenCenter={isNotifCenterOpen}
        onCloseCenter={() => setIsNotifCenterOpen(false)}
        notificationsList={notifications}
        onMarkAllAsRead={() =>
          setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
        }
      />

      {/* 24h Technical Support Modal */}
      <Support24hModal
        isOpen={isSupportOpen}
        onClose={() => setIsSupportOpen(false)}
        userType={
          activeTab === 'admin'
            ? 'admin'
            : activeTab === 'driver_portal'
            ? 'driver'
            : 'passenger'
        }
      />

      {/* Emergency SOS & Security Modal */}
      <SosModal
        isOpen={isSosOpen}
        onClose={() => setIsSosOpen(false)}
        currentLocation={
          activeRide?.pickup?.address ||
          pickup?.address ||
          'Av. Presidente Vargas, 1250 - Centro, Indaiatuba-SP'
        }
        currentLat={activeRide?.pickup?.lat ?? pickup?.lat}
        currentLng={activeRide?.pickup?.lng ?? pickup?.lng}
      />

      {/* Share Platform Modal */}
      <ShareModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
      />

      {/* Universal Login & Cadastro Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={handleAuthSuccess}
        initialRole={activeTab === 'driver_portal' ? 'driver' : 'passenger'}
      />


      {/* Ergonomic Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={(tab) => {
          if (tab === 'admin') {
            const isUserAdmin = Boolean(
              currentUser?.email?.toLowerCase() === 'admin@race.com.br' ||
              currentUser?.role === 'admin' ||
              currentUser?.isAdmin === true ||
              String(currentUser?.tipo || '').toUpperCase() === 'ADM'
            );
            if (!isUserAdmin) return;
          }

          setActiveTab(tab);
        }}
        isDriverOnline={currentDriver.status === 'online'}
        currentUser={currentUser}
      />

      {/* 1. Página de Mapa Fullscreen Toda Tela Sem Nenhuma Informação por Cima (Somente com corrida paga ou em dinheiro) */}
      {isFullMapOpen &&
        activeRide &&
        (activeRide.paymentStatus === 'paid' ||
          activeRide.paymentMethod === 'money' ||
          activeRide.paymentMethod === 'dinheiro') && (() => {
          const targetRideCat = normalizeRideCategory(activeRide.category);
          const matchingOnlineDrivers = drivers.filter((d) => {
            if (d.status !== 'online' || d.categoryConfigured === false) return false;
            return normalizeRideCategory(d.category) === targetRideCat;
          });
          return (
            <FullMapView
              onClose={() => setIsFullMapOpen(false)}
              pickup={pickup}
              destination={destination}
              activeDriver={activeRide.driver ?? null}
              activeRide={activeRide}
              currentUserAvatar={currentUser?.avatar}
              currentUserName={currentUser?.name}
              onlineDrivers={matchingOnlineDrivers}
              onCompleteRide={handleCompleteRide}
              onCancelRide={handleCancelRide}
              onUpdateDriverPosition={(pos) => {
                setDriverPosition((prev) => {
                  if (prev && prev.lat === pos.lat && prev.lng === pos.lng) return prev;
                  return pos;
                });
              }}
            />
          );
        })()}

      {/* Modal de Avaliação do Motorista / Motoboy ao Concluir Corrida */}
      <RatingModal
        isOpen={isRatingModalOpen}
        ride={completedRideForRating || activeRide}
        onSubmitRating={handleSubmitRating}
        onClose={() => {
          setIsRatingModalOpen(false);
          setActiveRide(null);
        }}
      />
    </div>
  );
}
